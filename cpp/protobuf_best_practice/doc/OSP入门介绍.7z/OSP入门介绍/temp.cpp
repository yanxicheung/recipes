    struct OSP_API CApp
#endif
{
#if defined(PWLIB_SUPPORT) && defined(_LINUX_)
    PCLASSINFO(CApp, PThread);
#endif

public:
    //应用接收消息总数
    u32 msgIncome;
    //应用已处理消息总数
    u32 msgProcessed;
    //应用邮箱中待处理的消息总数(未使用)
    u32 msgWaiting;
    //应用邮箱中待处理的消息总数峰值
    u32 msgWaitingTop;
    //已激发的定时消息总数
    u32 timerProcessed;
    //应用邮箱最大消息容量
    u32 maxMsgWaiting;
    //因邮箱满丢弃的消息总数
    u32 msgdropped;
    //应用别名
    char * pAppName;

    //应用主邮箱写句柄
    MAILBOXID queSendId;
    //应用主邮箱读句柄
    MAILBOXID queRcvId;

    /* 为支持同步消息而增加的消息备份队列，存放同步消息发送后，应答超时消息
       或应答消息到达之前的所有消息 */
    //应用备邮箱中的消息总数
    u32 bakQueMsgNum;
    //应用备邮箱写句柄
    MAILBOXID bakQueSendId;
    //应用备邮箱读句柄
    MAILBOXID bakQueRcvId;

    //应用任务ID
    TASKID taskID;

    //屏幕trc标志 收发消息跟踪是否打印到屏幕标志
    u16 scrnTraceFlag;

    //文件trc标志 收发消息跟踪是否保存到日志文件标志
    u16 fileTraceFlag;

    //屏幕log级别 Instance::log()中进行控制
    u8 scrnLogFlag;

    //文件log级别 Instance::log()中进行控制
    u8 fileLogFlag;

    //应用ID
    u16 appId;
    //应用任务优先级
    u8 byAppPri;
    //应用前一个空闲实例号
    u16 wLastIdleInstID;

    //应用任务句柄
    TASKHANDLE hAppTask;
    //应用任务信号量句柄
    SEMHANDLE tSemMutex;

    // 当前收到的消息
    CMessage *curMsgRcv;
    // 当前发送的消息号
    u16 curEvtSnd;

private:
	// 用于记录实例最近状态和收到数据的环行缓冲
	u8 byInstInfoHead;
	u8 byInstInfoTail;
	TInstInfo tInstInfo[MAX_INSTINFO_NUM];

    //跟踪回调函数执行信息
    BOOL32 m_bCallBackInfoRecFlag;//记录回调执行信息开关 TRUE 记录 FALSE 不记录
	u8 m_byCallBackIndex; //环形缓冲的循环索引
    u32 m_dwCallBackCount;//回调函数执行累加的总次数
    //用于记录App最近回调函数调用信息的环行缓冲
	TCallBackInfo m_atCallBackInfo[APP_MAX_CALLBACK_RECORD];
public:

	CApp();

	virtual ~CApp();


    //根据实例号查询指定实例
    virtual class CInstance* GetInstance(u16 wInsid) = 0;
    //设定实例别名
    virtual BOOL32 SetInstAlias(u16 wInsID, const char* szAlias, u8 byLen) = 0;
    //根据别名查询指定实例
    virtual class CInstance* FindInstByAlias(const char* szAlias, u8 byLen) = 0;
    //得到应用最大实例数
    virtual s32 GetInstanceNumber() = 0;
    //得到实例别名最大长度
    virtual u8 GetMaxAliasLen() = 0;
    //初始化实例别名记录信息
    virtual BOOL32 InitAliasArray() = 0;
    //清除实例别名纪录信息
    virtual BOOL32 ClearInstAlias(u16 wInsID, const char* szAlias, u8 byLen) = 0;

    //启动应用
    // APP最高优先级为80，如果小于80，OSP将强制为80。此后, 用户可以调用OspSetAppPriority()或CApp::SetPriority()更改优先级.
    //成功返回OSP_OK      //操作成功    失败返回OSP_ERROR  //操作失败
    s32 CreateApp(const char* szName, u16 wAppId, u8 byPrior, u16 wQueueSize = 80, u32 dwStackSize = 200<<10);
    //设定应用任务优先级
    BOOL32 SetPriority(u8 byPrior);
    //查询任务优先级
    u8 GetPriority()
    {
        return byAppPri;
    }
    //应用退出
    //注意: 用户禁止调用QuitApp
    void QuitApp();

    //应用备邮箱消息总数增加减少查询
    BOOL32 BakMsgNumInc();
    BOOL32 BakMsgNumDec();
    u32 GetBakMsgNum();

    //应用主邮箱消息总数查询增加减少
    u32 GetMsgIncomeNum();
    void MsgIncomeNumInc();
    void MsgIncomeNumDec();

    //应用处理消息总数增加
    void MsgProcessedNumInc();

    //查询待处理的消息总数
    u32 GetMsgWaitingNum();

    //应用别名设定查询
    void SetName(const char* szName);
    char * NameGet();

    //定时激发次数增加
    void TimerProcessedIncrease();

    //设定文件屏幕log级别
    void LogLevelSet(u8 byFileLevel, u8 byScreenLevel);
    //设定文件屏幕trc标志
    void TrcFlagSet(u16 wFileFlag, u16 wScreenFlag);

    //实例简要信息打印
    void InstInfoShow();
    //实例简要信息增加
    void InstInfoAdd(u16 wInsID, u32 dwState, u16 wEvtRcv, u16 wEvtSnd);

	//获取本app的回调函数执行信息记录开关
    BOOL32 GetCallBackInfoRecordFlag(void);
	//设置本app的回调函数执行信息记录开关
    void   SetCallBackInfoRecordFlag(BOOL32 bFlag);

    //回调函数执行信息打印
	void CallBackInfoShow(void);

	//回调函数执行信息添加
	/*=============================================================================
	函数名      :CallBackInfoAddStart
	功能        :统计回调函数的信息，记录起始时间
	             只在AppEntry()中使用，是串行的，不需要锁
	             在执行回调函数之前调用
	算法实现    : 不加锁的原因是，AppEntry()内部时序上可以保证串行
	              Telnet显示线程和AppEntry()可能有冲突，但可以忽略
	参数说明    :
		[I] dwTick 回调函数执行前的时间
		[I] wInstId 执行回调的实例id
		[I] dwEvent 事件id
		[I] wMsgType 消息类型 MSG_TYPE_ASYNC 0 MSG_TYPE_SYNC 1
		    MSG_TYPE_SYNCACK 2  MSG_TYPE_GSYNC 3
		[I] pchFuncName 函数名指针
	返回值说明  :无
	-------------------------------------------------------------------------------
	修改记录    :
	日  期      版本        修改人        修改内容
	2015/05/20  1.0         邓昌葛        新建
	===============================================================================*/
    void CallBackInfoAddStart(u32 dwTick, u16 wInstId, u16 dwEvent,
                              u16 dwMsgType,char *pchFuncName);
	/*=============================================================================
	函数名      :CallBackInfoAddEnd
	功能        :统计回调函数的信息，记录截止时间
	             只在AppEntry()中使用，注意时序上保证和CallBackInfoAddStart一一对应
	             在执行回调函数之后调用
	算法实现    :
	参数说明    :
		[I] dwTick 回调函数执行完成的时刻
	返回值说明  :无
	-------------------------------------------------------------------------------
	修改记录    :
	日  期      版本        修改人        修改内容
	2015/05/20  1.0         邓昌葛        新建
	===============================================================================*/
    void CallBackInfoAddEnd(u32 dwTick);

#if defined(_LINUX_) && defined(PWLIB_SUPPORT)
    void Main();  // pwlib pure virtual function
#endif
};

